package ChessClient;
public class chessmain {

	public static void main(String args[])
	{
		 new login();
	}
}
