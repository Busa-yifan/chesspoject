package ChessClient;

public class Seat {
       String name,imgnum;
	   boolean issit;
	  
	   public Seat()
	   {
		   issit=false;
	   }
}
