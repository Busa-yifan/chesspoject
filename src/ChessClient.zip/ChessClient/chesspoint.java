package ChessClient;

public class chesspoint {
	int x;
	int y;
	String name="";
	String side="";
	boolean havechess=false;
	  
	  public chesspoint(String name)
	  {
		  havechess=false;
		  this.name=name;
		  
	  }
	
}
