package ChessServer;

public class ServerSeat {
	boolean issit = false;
	String name,imgnum;
	
	
	
	public ServerSeat()
	{
		name="";
		imgnum="";
		issit = false;
	}

}
